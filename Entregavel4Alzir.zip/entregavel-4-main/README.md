# entregavel-4
Para Executar os Testes, bastar rodar o script: npm test
